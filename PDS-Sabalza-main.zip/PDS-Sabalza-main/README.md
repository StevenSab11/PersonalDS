# PDS
Personal Data Sheet
This is my first Personal Data Sheet created in October 1, 2023.
2nd Year BSIT Studnet 
Eastern Visayas State Univeristy 

This file contains the following: 
HTML
Png
CSS / SCSS
